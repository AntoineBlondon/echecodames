from game_functions import *
from tableau import *
start()